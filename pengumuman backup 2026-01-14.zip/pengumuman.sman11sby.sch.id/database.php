<?php
error_reporting(E_ALL ^ E_DEPRECATED);
define('DB_HOST',"localhost");
define('DB_USER',"pengumuman");
define('DB_PASS',"vFmC8C1MamYYtzAwaD65");
define('DB_NAME',"lulus");

$db_conn = mysqli_connect(DB_HOST,DB_USER,DB_PASS,DB_NAME);


if(mysqli_connect_errno()){
	echo 'Gagal terhubung ke database: '.mysqli_connect_error();
	exit();
}
?>